function sayHello(){
    console.log("Hello");
}

sayHello();
sayHello();
sayHello();

function sayHello2(name, age){
    console.log("Hello my name is",name, "and i'm", age,"years old");
}
//쉼표 대신 +로 해도 됨. 
sayHello2("aa", 22);
sayHello2("vv", 11);
sayHello2("vvcc", 33 );
