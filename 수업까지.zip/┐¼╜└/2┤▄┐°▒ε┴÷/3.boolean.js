const a =true;
console.log('--------------------------------');
console.log('a:',a);

const b =null;
console.log('--------------------------------');
console.log('b:',b);

let c;
console.log('c:',c);
//null과 undefined는 다름. null은 빈값을 준 거고 undefined는 아예 지금 값이 없는 것임.