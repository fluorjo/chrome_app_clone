let a =33;
//let은 변경 가능함. 
const b =3;

a=5 ;
console.log('--------------------------------');
console.log('a:',a);

b=5 ;// 이거 에러남. 
console.log('--------------------------------');
console.log('b:',b);