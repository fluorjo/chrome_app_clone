const a =33;
const b =3;

//상수. 바뀌지 않는 값.

console.log('a+b:',a+b);
console.log('a*b:',a*b);
console.log('a/b:',a/b);