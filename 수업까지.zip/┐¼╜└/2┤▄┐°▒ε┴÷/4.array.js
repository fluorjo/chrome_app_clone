const week = ['mon','tue','wed','thu','fri', 'sat','sun'];

console.log('--------------------------------');
console.log('week:',week);
console.log('--------------------------------');
console.log('week[3]:',week[3]);
console.log('week[0]:',week[0]);

//배열에 항목 추가하기 

week.push("ww");
console.log('--------------------------------');
console.log('week:',week);