const title=document.getElementById("title");

title.innerText = "got"
console.log(title.id);
console.log(title.className);

