console.log('document')
console.log('document.title')
document.title="hi"
document.body
document.location