chrome-app-clone-'10 week study' in nomad coders
